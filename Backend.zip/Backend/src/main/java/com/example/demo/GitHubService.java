package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import java.util.Map;

@Service
public class GitHubService {

    private final String API_URL = "https://api.github.com/repos/sergioriveira/EGOS-app";
    private final RestTemplate restTemplate;
    
    @Value("${github.token}")
    private String token;

    public GitHubService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    private HttpEntity<String> getHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + token);
        headers.set("Accept", "application/vnd.github.v3+json");
        headers.set("User-Agent", "Spring-Boot-App");
        
        return new HttpEntity<>(headers);
    }

    public Map<String, Object> getRepoDetails() {
        return restTemplate.exchange(API_URL, HttpMethod.GET, getHeaders(), Map.class).getBody();
    }

    public Map<String, Object> getLatestRelease() {
        try {
            return restTemplate.exchange(API_URL + "/releases/latest", HttpMethod.GET, getHeaders(), Map.class).getBody();
        } catch (Exception e) {
            return null;
        }
    }
}