package com.example.demo;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import java.util.Map;

@Service
public class GitHubService {

    private final String API_URL = "https://api.github.com/repos/sergioriveira/EGOS-app";

    private HttpEntity<String> getHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Sergio", "Spring-Boot-App"); 
        return new HttpEntity<>(headers);
    }

    public Map<String, Object> getRepoDetails() {
        RestTemplate restTemplate = new RestTemplate();
        return restTemplate.exchange(API_URL, HttpMethod.GET, getHeaders(), Map.class).getBody();
    }

    public Map<String, Object> getLatestRelease() {
        RestTemplate restTemplate = new RestTemplate();
        return restTemplate.exchange(API_URL + "/releases/latest", HttpMethod.GET, getHeaders(), Map.class).getBody();
    }
}