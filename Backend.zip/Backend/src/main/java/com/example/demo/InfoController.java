package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/github")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class InfoController {

    @Autowired
    private GitHubService gitHubService;

    @GetMapping("/info")
    public Map<String, Object> getGitHubInfo() {
        Map<String, Object> repoData = gitHubService.getRepoDetails();
        Map<String, Object> releaseData = gitHubService.getLatestRelease();

        Map<String, Object> response = new HashMap<>();
        response.put("lastUpdate", repoData.get("updated_at"));
        response.put("version", releaseData.get("tag_name"));
        response.put("downloadUrl", releaseData.get("zipball_url"));

        return response;
    }
}