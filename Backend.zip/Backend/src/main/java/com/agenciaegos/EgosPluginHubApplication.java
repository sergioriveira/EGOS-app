package com.agenciaegos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EgosPluginHubApplication {

    public static void main(String[] args) {
        SpringApplication.run(EgosPluginHubApplication.class, args);
    }
}