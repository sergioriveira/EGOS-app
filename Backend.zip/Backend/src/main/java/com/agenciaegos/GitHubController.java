package com.agenciaegos;

import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/github")
public class GitHubController {

    private final GitHubService gitHubService;

    public GitHubController(GitHubService gitHubService) {
        this.gitHubService = gitHubService;
    }

    @GetMapping("/info")
    public Map<String, Object> getInfo(@RequestParam String repo) {
        return gitHubService.getCombinedRepoInfo(repo);
    }
}