package com.agenciaegos;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import java.util.Map;
import java.util.HashMap;
import java.util.List;

@Service
public class GitHubService {

    private final String BASE_API = "https://api.github.com/repos/agenciaegosdev/";
    private final RestClient restClient;
    
    @Value("${github.token}")
    private String token;

    public GitHubService(RestClient.Builder restClientBuilder) {
        this.restClient = restClientBuilder.build();
    }

    public Map<String, Object> getCombinedRepoInfo(String repoName) {
    Map<String, Object> response = new HashMap<>();
    String repoUrl = BASE_API + repoName;

    String cleanToken = (token != null) ? token.trim() : "";

    try {
        Map<String, Object> details = restClient.get()
                .uri(repoUrl)
                .header("Authorization", "Bearer " + cleanToken)
                .header("User-Agent", "Spring-Boot-App") 
                .header("Accept", "application/vnd.github.v3+json")
                .retrieve()
                .body(Map.class);
        
        if (details != null) {
            response.put("lastUpdate", details.get("updated_at"));
        }

        Map<String, Object> release = restClient.get()
                .uri(repoUrl + "/releases/latest")
                .header("Authorization", "Bearer " + cleanToken)
                .header("User-Agent", "Spring-Boot-App")
                .header("Accept", "application/vnd.github.v3+json")
                .retrieve()
                .body(Map.class);

        if (release != null) {
            response.put("version", release.get("tag_name"));
            
            List<Map<String, Object>> assets = (List<Map<String, Object>>) release.get("assets");
            if (assets != null && !assets.isEmpty()) {
                response.put("downloadUrl", assets.get(0).get("browser_download_url"));
            }
        }

    } catch (Exception e) {
        System.err.println("--- ERROR EN REPO: " + repoName + " ---");
        e.printStackTrace(); 
        
        response.put("version", "v0.0.0");
        response.put("lastUpdate", null);
        response.put("downloadUrl", null);
    }
    
        return response;
    }
}