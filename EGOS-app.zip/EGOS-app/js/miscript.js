window.onload = function() {
    cargarYActualizarDatos();
};

async function cargarYActualizarDatos() {
    try {
        const res = await fetch('http://localhost:8080/api/github/info');
        const data = await res.json();

        console.log("Datos recibidos del backend:", data);

        const versiones = document.querySelectorAll('.version-github');
        versiones.forEach(el => {
            el.innerText = data.version || "v0.0.0";
        });

        const fechas = document.querySelectorAll('.fecha-github');
        fechas.forEach(el => {
            if (data.lastUpdate) {
                const fecha = new Date(data.lastUpdate);
                if (!isNaN(fecha)) {
                    el.innerText = fecha.toLocaleDateString('es-ES');
                    el.setAttribute('data-fecha', data.lastUpdate);
                }
            }
        });

        const botones = document.querySelectorAll('.btn-github');
        botones.forEach(el => {
            if (data.downloadUrl) el.href = data.downloadUrl;
        });

        actualizarFechasRelativas();

    } catch (error) {
        console.error("Error conectando al backend:", error);
        document.querySelectorAll('.fecha-github').forEach(el => el.innerText = "Error");
    }
}

function actualizarFechasRelativas() {
    const etiquetasFecha = document.querySelectorAll('.fecha-tag');
    etiquetasFecha.forEach(tag => {
        const fechaStr = tag.getAttribute('data-fecha');
        if (!fechaStr) return;

        const fechaSubida = new Date(fechaStr);
        const hoy = new Date();
        
        hoy.setHours(0, 0, 0, 0);
        fechaSubida.setHours(0, 0, 0, 0);

        const diferenciaDias = Math.floor((hoy - fechaSubida) / (1000 * 60 * 60 * 24));

        if (diferenciaDias === 0) tag.textContent = "Hoy";
        else if (diferenciaDias === 1) tag.textContent = "Ayer";
        else if (diferenciaDias < 7) tag.textContent = `Hace ${diferenciaDias} días`;
        else {
            const semanas = Math.floor(diferenciaDias / 7);
            tag.textContent = semanas === 1 ? "Hace 1 semana" : `Hace ${semanas} semanas`;
        }
    });
}