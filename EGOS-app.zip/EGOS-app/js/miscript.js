window.onload = function() {
    actualizarFechas();
    actualizarVersion();
};

function actualizarFechas() {
    const etiquetasFecha = document.querySelectorAll('.fecha-tag');
    
    etiquetasFecha.forEach(tag => {
        const fechaSubidaString = tag.getAttribute('data-fecha');
        if (!fechaSubidaString) return; // ponemos seguridad por si falta el atributo

        const fechaSubida = new Date(fechaSubidaString);
        const hoy = new Date();

        // Limpiamos horas para que podamos comparar solo días
        hoy.setHours(0, 0, 0, 0);
        fechaSubida.setHours(0, 0, 0, 0);

        const diferenciaDias = Math.floor((hoy - fechaSubida) / (1000 * 60 * 60 * 24));

        if (diferenciaDias === 0) {
            tag.textContent = "Actualizado hoy";
        } else if (diferenciaDias === 1) {
            tag.textContent = "Hace 1 día";
        } else {
            tag.textContent = `Hace ${diferenciaDias} días`;
        }
    });
}

function actualizarVersion(){
    
}