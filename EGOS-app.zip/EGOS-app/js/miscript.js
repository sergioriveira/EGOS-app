window.onload = function() {
    actualizarFechas();
};

function actualizarFechas() {
    const etiquetasFecha = document.querySelectorAll('.fecha-tag');
    console.log(etiquetasFecha);

    etiquetasFecha.forEach(tag => {
        const fechaSubidaString = tag.getAttribute('data-fecha');
        if (!fechaSubidaString) return; // ponemos seguridad por si falta el atributo

        const fechaSubida = new Date(fechaSubidaString);
        const hoy = new Date();

        // Limpiamos horas para que podamos comparar solo días
        hoy.setHours(0, 0, 0, 0);
        fechaSubida.setHours(0, 0, 0, 0);

        const diferenciaDias = Math.floor((hoy - fechaSubida) / (1000 * 60 * 60 * 24));

        if (diferenciaDias === 0) {
            tag.textContent = "Hoy";
        } 
        else if (diferenciaDias === 1) {
            tag.textContent = "Ayer";
        } 
        else if (diferenciaDias < 7) {
            tag.textContent = 'Hace '+diferenciaDias+' días';
        } 
        else {
            const semanas = Math.floor(diferenciaDias / 7);
            tag.textContent = semanas === 1 
            ? "Hace 1 semana" 
            : 'Hace '+semanas+' semanas';
        }
    });
}