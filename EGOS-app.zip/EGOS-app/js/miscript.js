const BACKEND_URL = "/api/github/info";

document.addEventListener('DOMContentLoaded', () => {
    activarDescargas(); 
    inicializarDashboard();
    cargarPluginsDesdeStorage();
    configurarVista();
});

// Inicializar Dashboard
async function inicializarDashboard() {
    configurarBuscador();
    configurarFiltrosCategorias();
    
    const btnUpload = document.getElementById('btn-upload');
    const fileInput = document.getElementById('plugin-file-input');

    if (btnUpload && fileInput) {
        btnUpload.addEventListener('click', () => {
            fileInput.click();
        });

        fileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                crearOActualizarTarjeta(e.target.files[0]);
            }
        });
    }
    await cargarDatosDePlugins();
}

// CARGA DINÁMICA DE REPOSITORIOS
async function cargarDatosDePlugins() {
    const cards = document.querySelectorAll('.plugin-card');
    
    for (const card of cards) {
        const btnDescarga = card.querySelector('.btn-download');
        const repoName = btnDescarga ? btnDescarga.getAttribute('data-repo') : null;

        if (!repoName) continue;

        try {
            const res = await fetch(`${BACKEND_URL}?repo=${repoName}`);

            if (!res.ok) throw new Error(`Error en repo ${repoName}`);
            
            const data = await res.json();

            const versionEl = card.querySelector('.version-github');
            const fechaEl = card.querySelector('.fecha-github');

            if (versionEl) {
                versionEl.innerText = data.version || "v0.0.0";
            }
            
            if (fechaEl && data.lastUpdate) {
                fechaEl.innerText = new Date(data.lastUpdate).toLocaleDateString('es-ES');
            }

            if (btnDescarga && data.downloadUrl) {
                btnDescarga.href = data.downloadUrl;
            }

        } catch (error) {
            console.error(`Error llamando al repo ${repoName}:`, error);
            const versionEl = card.querySelector('.version-github');
            if (versionEl) versionEl.innerText = "Error";
        }
    }

    actualizarContadoresGlobales();
}

//Configurar buscador
function configurarBuscador() {
    const searchInput = document.getElementById('search-input');
    if (!searchInput) return;

    searchInput.addEventListener('input', (e) => {
        const valor = e.target.value.toLowerCase().trim();
        const cards = document.querySelectorAll('.plugin-card');

        cards.forEach(card => {
            const h3 = card.querySelector('h3');
            const p = card.querySelector('p');
            if (!h3 || !p) return;

            const nombre = h3.innerText.toLowerCase();
            const descripcion = p.innerText.toLowerCase();
            
            card.style.display = (nombre.includes(valor) || descripcion.includes(valor)) ? "flex" : "none";
        });
    });
}

//Configurar filtros de categorías
function configurarFiltrosCategorias() {
    const botonesFiltro = document.querySelectorAll('.filter-btn, .nav-btn');
    
    botonesFiltro.forEach(btn => {
        btn.addEventListener('click', () => {
            const filtro = btn.getAttribute('data-filter');
            
            botonesFiltro.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            const cards = document.querySelectorAll('.plugin-card');
            cards.forEach(card => {
                const categoria = card.getAttribute('data-category') || "";
                const coincide = (filtro === 'all' || categoria.includes(filtro));
                card.style.display = coincide ? "flex" : "none";
            });
        });
    });
}

//activar descargas
function activarDescargas() {
    const botonesDescarga = document.querySelectorAll('.btn-download');
    const contadorGlobal = document.getElementById('stat-downloads');
    if (!contadorGlobal) return;

    const descargasGuardadas = localStorage.getItem('totalDescargas');
    if (descargasGuardadas) {
        contadorGlobal.innerText = descargasGuardadas;
    }

    botonesDescarga.forEach(boton => {
        boton.onclick = (e) => {
            const href = boton.getAttribute('href');
            
            if (!href || href === '#') {
                e.preventDefault();
            }

            let descargasActuales = parseInt(contadorGlobal.innerText) || 0;
            descargasActuales++;
            contadorGlobal.innerText = descargasActuales;
            localStorage.setItem('totalDescargas', descargasActuales);
        };
    });
}

//Actualizar controladores golobales
function actualizarContadoresGlobales() {
    const totalPlugins = document.querySelectorAll('.plugin-card').length;
    const elTotal = document.getElementById('stat-plugins');
    if (elTotal) elTotal.innerText = totalPlugins;

    const totalActualizados = document.querySelectorAll('.plugin-card .badge.actualizado').length;
    const elUpdated = document.getElementById('stat-updated');
    if (elUpdated) elUpdated.innerText = totalActualizados;

    const totalNuevos = document.querySelectorAll('.plugin-card .badge.nuevo').length;
    const elNew = document.getElementById('stat-new');
    if (elNew) elNew.innerText = totalNuevos;
}

//Crear o Actualizar tarjeta
function crearOActualizarTarjeta(file) {
    const nombreLimpio = file.name.replace(/\.[^/.]+$/, ""); 
    const fechaActual = new Date().toLocaleDateString('es-ES');
    const pesoFormateado = (file.size / 1024).toFixed(1) + " KB";
    
    const nuevoPlugin = {
        nombre: nombreLimpio,
        fecha: fechaActual,
        peso: pesoFormateado,
        categoria: 'Otros',
        version: 'v1.0.0'
    };

    renderizarTarjetaEnDOM(nuevoPlugin);

    let pluginsLocales = JSON.parse(localStorage.getItem('misPluginsLocales')) || [];
    const index = pluginsLocales.findIndex(p => p.nombre === nuevoPlugin.nombre);
    
    if (index !== -1) {
        pluginsLocales[index] = nuevoPlugin;
    } else {
        pluginsLocales.push(nuevoPlugin);
    }
    
    localStorage.setItem('misPluginsLocales', JSON.stringify(pluginsLocales));

    const fileInput = document.getElementById('plugin-file-input');
    if (fileInput) fileInput.value = "";
}

//Renderizar Tarjeta
function renderizarTarjetaEnDOM(plugin) {
    const grid = document.getElementById('plugin-grid');
    if (!grid) return;

    const tarjetasExistentes = document.querySelectorAll('.plugin-card h3');
    let tarjetaExistente = null;

    tarjetasExistentes.forEach(titulo => {
        if (titulo.innerText.toLowerCase() === plugin.nombre.toLowerCase()) {
            tarjetaExistente = titulo.closest('.plugin-card');
        }
    });

    if (tarjetaExistente) {
        tarjetaExistente.querySelector('.version-github').innerText = plugin.version + " (Actualizado)";
        tarjetaExistente.querySelector('.metadata span:nth-of-type(2)').innerText = plugin.peso;
        tarjetaExistente.querySelector('.fecha-github').innerText = plugin.fecha;
    } else {
        const nuevaTarjeta = document.createElement('article');
        nuevaTarjeta.className = 'plugin-card';
        nuevaTarjeta.setAttribute('data-category', plugin.categoria);

        nuevaTarjeta.innerHTML = `
        <div class="card-header">
            <svg class="icon-svg icon-main"><use href="iconos.svg#plus"></use></svg>
            <span class="badge nuevo">Nuevo</span>
            <button class="btn-delete" title="Eliminar plugin" style="background:none; border:none; cursor:pointer; color:#ff4d4d; font-weight:bold; margin-left: auto;">
                ✕
            </button>
        </div>
        <h3>${plugin.nombre}</h3>
        <p>Plugin subido localmente. Guardado en el navegador.</p>
        <div class="metadata">
            <svg class="icon-svg icon-main"><use href="iconos.svg#version"></use></svg>
                <span class="version-github">${plugin.version}</span>
            <svg class="icon-svg icon-main"><use href="iconos.svg#peso"></use></svg>
            <span>${plugin.peso}</span>
                <svg class="icon-svg icon-main"><use href="iconos.svg#tiempo"></use></svg>
            <span class="fecha-github">${plugin.fecha}</span>
        </div>
        <a href="#" class="btn-download">
            <svg class="icon-svg icon-main"><use href="iconos.svg#descargar"></use></svg> Descargar
        </a>
        `;

        const btnDelete = nuevaTarjeta.querySelector('.btn-delete');
        btnDelete.onclick = () => eliminarPlugin(plugin.nombre, nuevaTarjeta);
        
        grid.prepend(nuevaTarjeta);
    }

    activarDescargas();
    actualizarContadoresGlobales();
}

//Cargar las plugins desde el localStorage
function cargarPluginsDesdeStorage() {
    const pluginsGuardados = JSON.parse(localStorage.getItem('misPluginsLocales')) || [];
    pluginsGuardados.forEach(plugin => {
        renderizarTarjetaEnDOM(plugin);
    });
    actualizarContadoresGlobales();
}

//Eliminar plugin
function eliminarPlugin(nombrePlugin, elementoHTML) {
    if (confirm(`¿Estás seguro de que quieres eliminar el plugin "${nombrePlugin}"?`)) {
        let plugins = JSON.parse(localStorage.getItem('misPluginsLocales')) || [];
        
        plugins = plugins.filter(p => p.nombre !== nombrePlugin);
        
        localStorage.setItem('misPluginsLocales', JSON.stringify(plugins));

        elementoHTML.remove();

        actualizarContadoresGlobales();
    }
}

//Configuramos el botón de Vista
function configurarVista() {
    const btnView = document.getElementById('btn-view');
    const grid = document.getElementById('plugin-grid');
    
    if (btnView && grid) {
        btnView.addEventListener('click', () => {
            grid.classList.toggle('list-view');
            const isList = grid.classList.contains('list-view');
            btnView.innerHTML = isList ? 
                `<svg class="icon-svg icon-main"><use href="iconos.svg#cuadrados"></use></svg> Vista Grid` : 
                `<svg class="icon-svg icon-main"><use href="iconos.svg#vista"></use></svg> Vista Lista`;
        });
    }
}