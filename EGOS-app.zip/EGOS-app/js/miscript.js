document.addEventListener('DOMContentLoaded', () => {
    activarDescargas(); 
    inicializarDashboard(); 
});

async function inicializarDashboard() {
    configurarBuscador();
    configurarFiltrosCategorias();
    await cargarDatosDePlugins();
}

async function cargarDatosDePlugins() {
    const cards = document.querySelectorAll('.plugin-card');
    
    const BACKEND_URL = "http://217-160-204-193:8080/api/github/info";

    for (const card of cards) {
        try {
            const res = await fetch(BACKEND_URL);

            if (!res.ok) throw new Error('Error al conectar con el servidor Java');
            
            const data = await res.json();

            const versionEl = card.querySelector('.version-github');
            const fechaEl = card.querySelector('.fecha-github');

            if (versionEl) {
                versionEl.innerText = data.version || "main";
            }
            
            if (fechaEl && data.lastUpdate) {
                fechaEl.setAttribute('data-fecha', data.lastUpdate);
                fechaEl.innerText = new Date(data.lastUpdate).toLocaleDateString('es-ES');
            }

            const btnDescarga = card.querySelector('.btn-download');
            if (btnDescarga && data.downloadUrl) {
                btnDescarga.href = data.downloadUrl;
            }

        } catch (error) {
            console.error(`Error llamando al backend:`, error);
            const fechaEl = card.querySelector('.fecha-github');
            if (fechaEl) fechaEl.innerText = "No disponible";
        }
    }

    actualizarContadoresGlobales();
}

function configurarBuscador() {
    const searchInput = document.getElementById('search-input');
    if (!searchInput) return;

    searchInput.addEventListener('input', (e) => {
        const valor = e.target.value.toLowerCase().trim();
        const cards = document.querySelectorAll('.plugin-card');

        cards.forEach(card => {
            const h3 = card.querySelector('h3');
            const p = card.querySelector('p');
            if (!h3 || !p) return;

            const nombre = h3.innerText.toLowerCase();
            const descripcion = p.innerText.toLowerCase();
            
            card.style.display = (nombre.includes(valor) || descripcion.includes(valor)) ? "flex" : "none";
        });
    });
}

function configurarFiltrosCategorias() {
    const botonesFiltro = document.querySelectorAll('.filter-btn, .nav-btn');
    
    botonesFiltro.forEach(btn => {
        btn.addEventListener('click', () => {
            const filtro = btn.getAttribute('data-filter');
            
            botonesFiltro.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            const cards = document.querySelectorAll('.plugin-card');
            cards.forEach(card => {
                const categoria = card.getAttribute('data-category');
                card.style.display = (filtro === 'all' || categoria === filtro) ? "flex" : "none";
            });
        });
    });
}

function activarDescargas() {
    const botonesDescarga = document.querySelectorAll('.plugin-card .btn-download');
    const contadorGlobal = document.getElementById('stat-downloads');

    // Aquí comprobamos si ya hay un valor en el contador
    const descargasGuardadas = localStorage.getItem('totalDescargas');
    
    if (descargasGuardadas) {
        contadorGlobal.innerText = descargasGuardadas;
    }

    botonesDescarga.forEach(boton => {
        boton.addEventListener('click', (e) => {
            // Obtenemos el valor del HTML
            let descargasActuales = parseInt(contadorGlobal.innerText);
            
            descargasActuales++;

            contadorGlobal.innerText = descargasActuales;

            //Guardamos el nuevo valor en localStorage
            localStorage.setItem('totalDescargas', descargasActuales);

            const nombrePlugin = boton.closest('.plugin-card').querySelector('h3').innerText;
            console.log(`Guardado en local: ${nombrePlugin}. Nuevo total: ${descargasActuales}`);
        });
    });
}

function actualizarContadoresGlobales() {
    const totalPlugins = document.querySelectorAll('.plugin-card').length;
    const elTotal = document.getElementById('stat-plugins');
    if (elTotal) elTotal.innerText = totalPlugins;
}