document.addEventListener('DOMContentLoaded', () => {
    activarDescargas(); 
    inicializarDashboard();
    cargarPluginsDesdeStorage();
});

//Iniciarlizar Dashboard
async function inicializarDashboard() {
    configurarBuscador();
    configurarFiltrosCategorias();
    
    const btnUpload = document.getElementById('btn-upload');
    const fileInput = document.getElementById('plugin-file-input');

    if (btnUpload && fileInput) {
        btnUpload.addEventListener('click', () => {
            fileInput.click();
        });

        fileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                crearOActualizarTarjeta(e.target.files[0]);
            }
        });
    }
    await cargarDatosDePlugins();
}

//Cargar los datos de las plugins
async function cargarDatosDePlugins() {
    const cards = document.querySelectorAll('.plugin-card');
    
    const BACKEND_URL = "http://217-160-204-193:8080/api/github/info";

    for (const card of cards) {
        try {
            const res = await fetch(BACKEND_URL);

            if (!res.ok) throw new Error('Error al conectar con el servidor Java');
            
            const data = await res.json();

            const versionEl = card.querySelector('.version-github');
            const fechaEl = card.querySelector('.fecha-github');

            if (versionEl) {
                versionEl.innerText = data.version || "main";
            }
            
            if (fechaEl && data.lastUpdate) {
                fechaEl.setAttribute('data-fecha', data.lastUpdate);
                fechaEl.innerText = new Date(data.lastUpdate).toLocaleDateString('es-ES');
            }

            const btnDescarga = card.querySelector('.btn-download');
            if (btnDescarga && data.downloadUrl) {
                btnDescarga.href = data.downloadUrl;
            }

        } catch (error) {
            console.error(`Error llamando al backend:`, error);
            const fechaEl = card.querySelector('.fecha-github');
            if (fechaEl) fechaEl.innerText = "No disponible";
        }
    }

    actualizarContadoresGlobales();
}

//Configurar buscador
function configurarBuscador() {
    const searchInput = document.getElementById('search-input');
    if (!searchInput) return;

    searchInput.addEventListener('input', (e) => {
        const valor = e.target.value.toLowerCase().trim();
        const cards = document.querySelectorAll('.plugin-card');

        cards.forEach(card => {
            const h3 = card.querySelector('h3');
            const p = card.querySelector('p');
            if (!h3 || !p) return;

            const nombre = h3.innerText.toLowerCase();
            const descripcion = p.innerText.toLowerCase();
            
            card.style.display = (nombre.includes(valor) || descripcion.includes(valor)) ? "flex" : "none";
        });
    });
}

//Configurar filtros de categorías
function configurarFiltrosCategorias() {
    const botonesFiltro = document.querySelectorAll('.filter-btn, .nav-btn');
    
    botonesFiltro.forEach(btn => {
        btn.addEventListener('click', () => {
            const filtro = btn.getAttribute('data-filter');
            
            botonesFiltro.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            const cards = document.querySelectorAll('.plugin-card');
            cards.forEach(card => {
                const categoria = card.getAttribute('data-category');
                card.style.display = (filtro === 'all' || categoria === filtro) ? "flex" : "none";
            });
        });
    });
}

//activar descargas
function activarDescargas() {
    const botonesDescarga = document.querySelectorAll('.plugin-card .btn-download');
    const contadorGlobal = document.getElementById('stat-downloads');
    if (!contadorGlobal) return;

    const descargasGuardadas = localStorage.getItem('totalDescargas');
    if (descargasGuardadas) {
        contadorGlobal.innerText = descargasGuardadas;
    }

    botonesDescarga.forEach(boton => {
        boton.onclick = (e) => {
            e.preventDefault();
            let descargasActuales = parseInt(contadorGlobal.innerText) || 0;
            descargasActuales++;
            contadorGlobal.innerText = descargasActuales;
            localStorage.setItem('totalDescargas', descargasActuales);
        };
    });
}

//Actualizar controladores golobales
function actualizarContadoresGlobales() {
    const totalPlugins = document.querySelectorAll('.plugin-card').length;
    const elTotal = document.getElementById('stat-plugins');
    if (elTotal) elTotal.innerText = totalPlugins;
}

//Crear o Actualizar tarjeta
function crearOActualizarTarjeta(file) {
    const nombreLimpio = file.name.replace(/\.[^/.]+$/, ""); 
    const fechaActual = new Date().toLocaleDateString('es-ES');
    const pesoFormateado = (file.size / 1024).toFixed(1) + " KB";
    
    const nuevoPlugin = {
        nombre: nombreLimpio,
        fecha: fechaActual,
        peso: pesoFormateado,
        categoria: 'Otros',
        version: 'v1.0.0'
    };

    renderizarTarjetaEnDOM(nuevoPlugin);

    let pluginsLocales = JSON.parse(localStorage.getItem('misPluginsLocales')) || [];
    const index = pluginsLocales.findIndex(p => p.nombre === nuevoPlugin.nombre);
    
    if (index !== -1) {
        pluginsLocales[index] = nuevoPlugin;
    } else {
        pluginsLocales.push(nuevoPlugin);
    }
    
    localStorage.setItem('misPluginsLocales', JSON.stringify(pluginsLocales));

    const fileInput = document.getElementById('plugin-file-input');
    if (fileInput) fileInput.value = "";
}

//Renderizar Tarjeta
function renderizarTarjetaEnDOM(plugin) {
    const grid = document.getElementById('plugin-grid');
    if (!grid) return;

    const tarjetasExistentes = document.querySelectorAll('.plugin-card h3');
    let tarjetaExistente = null;

    tarjetasExistentes.forEach(titulo => {
        if (titulo.innerText.toLowerCase() === plugin.nombre.toLowerCase()) {
            tarjetaExistente = titulo.closest('.plugin-card');
        }
    });

    if (tarjetaExistente) {
        tarjetaExistente.querySelector('.version-github').innerText = plugin.version + " (Actualizado)";
        tarjetaExistente.querySelector('.metadata span:nth-of-type(2)').innerText = plugin.peso;
        tarjetaExistente.querySelector('.fecha-github').innerText = plugin.fecha;
    } else {
        const nuevaTarjeta = document.createElement('article');
        nuevaTarjeta.className = 'plugin-card';
        nuevaTarjeta.setAttribute('data-category', plugin.categoria);

        nuevaTarjeta.innerHTML = `
        <div class="card-header">
            <svg class="icon-svg icon-main"><use href="iconos.svg#plus"></use></svg>
            <span class="badge nuevo">Nuevo</span>
            <button class="btn-delete" title="Eliminar plugin" style="background:none; border:none; cursor:pointer; color:#ff4d4d; font-weight:bold; margin-left: auto;">
                ✕
            </button>
        </div>
        <h3>${plugin.nombre}</h3>
        <p>Plugin subido localmente. Guardado en el navegador.</p>
        <div class="metadata">
            <svg class="icon-svg icon-main"><use href="iconos.svg#version"></use></svg>
                <span class="version-github">${plugin.version}</span>
            <svg class="icon-svg icon-main"><use href="iconos.svg#peso"></use></svg>
            <span>${plugin.peso}</span>
                <svg class="icon-svg icon-main"><use href="iconos.svg#tiempo"></use></svg>
            <span class="fecha-github">${plugin.fecha}</span>
        </div>
        <a href="#" class="btn-download">
            <svg class="icon-svg icon-main"><use href="iconos.svg#descargar"></use></svg> Descargar
        </a>
        `;

        const btnDelete = nuevaTarjeta.querySelector('.btn-delete');
        btnDelete.onclick = () => eliminarPlugin(plugin.nombre, nuevaTarjeta);
        
        grid.prepend(nuevaTarjeta);
    }

    activarDescargas();
    actualizarContadoresGlobales();
}

//Cargar las plugins desde el localStorage
function cargarPluginsDesdeStorage() {
    const pluginsGuardados = JSON.parse(localStorage.getItem('misPluginsLocales')) || [];
    pluginsGuardados.forEach(plugin => {
        renderizarTarjetaEnDOM(plugin);
    });
    actualizarContadoresGlobales();
}

//Guardar las plugins en localStorge
function guardarPluginEnStorage(nuevoPlugin) {
    let plugins = JSON.parse(localStorage.getItem('misPluginsLocales')) || [];
    
    // Evitamos duplicados por nombre
    const index = plugins.findIndex(p => p.nombre === nuevoPlugin.nombre);
    if (index !== -1) {
        plugins[index] = nuevoPlugin; // Actualizar si ya existe el pluggin
    } else {
        plugins.push(nuevoPlugin);
    }
    
    localStorage.setItem('misPluginsLocales', JSON.stringify(plugins));
}

//Eliminar plugin
function eliminarPlugin(nombrePlugin, elementoHTML) {
    if (confirm(`¿Estás seguro de que quieres eliminar el plugin "${nombrePlugin}"?`)) {
        let plugins = JSON.parse(localStorage.getItem('misPluginsLocales')) || [];
        
        plugins = plugins.filter(p => p.nombre !== nombrePlugin);
        
        localStorage.setItem('misPluginsLocales', JSON.stringify(plugins));

        elementoHTML.remove();

        actualizarContadoresGlobales();
        
        console.log(`Plugin "${nombrePlugin}" eliminado definitivamente.`);
    }
}